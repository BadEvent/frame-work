<?php

return [
	'host' => 'localhost',
	'name' => 'cms',
	'user' => 'root',
	'password' => '',
];