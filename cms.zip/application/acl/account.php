<?php

return [
	'all' => [

	],
	'authorize' => [
		'profile',
        'logout',
	],
	'guest' => [
        'register',
        'login',
        'recovery',
        'confirm',
	],
	'admin' => [
		//
	],
];